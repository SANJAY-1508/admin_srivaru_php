<?php
include("../config/db_config.php");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit();
}

$json = file_get_contents('php://input');
$obj = json_decode($json, true); // Use true for associative array
$output = array();
date_default_timezone_set('Asia/Calcutta');
$timestamp = date('Y-m-d H:i:s');
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
$domain = $_SERVER['HTTP_HOST'];
$base_url = $protocol . $domain . "/admin_srivaru/api";



function processImage($base64Data, $prefix)
{
    global $base_url;
    if (!preg_match('/^data:image\/(\w+);base64,/', $base64Data, $type)) {
        return ['error' => "Unsupported file type. Only images are allowed."];
    }
    $fileName = uniqid($prefix . "_") . "." . strtolower($type[1]);
    $filePath = "../Uploads/images/" . $fileName;
    $fileData = preg_replace('/^data:.*;base64,/', '', $base64Data);
    $decodedFile = base64_decode($fileData);
    if ($decodedFile === false) {
        return ['error' => "Base64 decoding failed."];
    }
    $directory = dirname($filePath);
    if (!is_dir($directory)) {
        mkdir($directory, 0777, true);
    }
    if (file_put_contents($filePath, $decodedFile) === false) {
        return ['error' => "Failed to save the image."];
    }
    $cleaned_path = str_replace('../', '', $filePath);
    return ['path' => $base_url . '/' . $cleaned_path];
}

// <<<<<<<<<<===================== List CSR Entries =====================>>>>>>>>>>
if (isset($obj['search_text']) && (!isset($obj['action']) || $obj['action'] !== 'list_error')) {
    $search_text = $conn->real_escape_string($obj['search_text']);
    $query = "SELECT * FROM `csr_entry` 
              WHERE `delete_at` = 0 
              AND (`csr_no` LIKE ? OR `customer_name` LIKE ?) 
              ORDER BY `id` DESC";
    $stmt = $conn->prepare($query);
    $search_param = "%" . $search_text . "%";
    $stmt->bind_param("ss", $search_param, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result === false) {
        error_log("CSR query failed: " . $conn->error);
        $output["head"]["code"] = 500;
        $output["head"]["msg"] = "Database error";
        echo json_encode($output, JSON_NUMERIC_CHECK);
        exit();
    }

    $entries = [];
    while ($row = $result->fetch_assoc()) {
        $row['parts_data'] = json_decode($row['parts_data'], true) ?? [];
        $row['employee_sign'] = !empty($row['employee_sign']) ? $base_url . '/' . str_replace('../', '', $row['employee_sign']) : '';
        $row['incharge_operator_sign'] = !empty($row['incharge_operator_sign']) ? $base_url . '/' . str_replace('../', '', $row['incharge_operator_sign']) : '';
        $entries[] = $row;
    }

    $output["head"]["code"] = 200;
    $output["head"]["msg"] = $result->num_rows > 0 ? "Success" : "No records found";
    $output["body"]["csr_entries"] = $entries;
    $stmt->close();
}
// <<<<<<<<<<===================== List error =====================>>>>>>>>>>
elseif (isset($obj['action']) && $obj['action'] === 'list_error' && isset($obj['search_text'])) {
    // Existing list_error code remains unchanged
    try {
        $search_text = $conn->real_escape_string($obj['search_text']);
        $query = "SELECT * FROM `error` WHERE (`error_code` LIKE ? OR `error_describtion` LIKE ?) AND `delete_at` = 0 ORDER BY id DESC";
        $stmt = $conn->prepare($query);
        $search_param = "%" . $search_text . "%";
        $stmt->bind_param("ss", $search_param, $search_param);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result === false) {
            throw new Exception("Query failed: " . $conn->error);
        }

        $errors = [];
        while ($row = $result->fetch_assoc()) {
            $errors[] = $row;
        }

        $output["head"]["code"] = 200;
        $output["head"]["msg"] = $result->num_rows > 0 ? "Success" : "No errors found";
        $output["body"]["errors"] = $errors;
        $stmt->close();
    } catch (Exception $e) {
        error_log("Error listing errors: " . $e->getMessage());
        $output["head"]["code"] = 400;
        $output["head"]["msg"] = "Failed to retrieve errors. Please try again.";
    }
}
// <<<<<<<<<<===================== Create CSR Entry =====================>>>>>>>>>>
elseif (isset($obj['csr_no']) && !isset($obj['edit_csr_entry_id'])) {
    $fields = [
        'csr_no' => $conn->real_escape_string($obj['csr_no'] ?? ''),
        'csr_entry_date' => $conn->real_escape_string($obj['csr_entry_date'] ?? ''),
        'customer_id' => $conn->real_escape_string($obj['customer_id'] ?? ''),
        'customer_name' => $conn->real_escape_string($obj['customer_name'] ?? ''),
        'contract_id' => $conn->real_escape_string($obj['contract_id'] ?? ''),
        'contract_type' => $conn->real_escape_string($obj['contract_type'] ?? ''),
        'error_id' => $conn->real_escape_string($obj['error_id'] ?? ''),
        'error_details' => $conn->real_escape_string($obj['error_details'] ?? ''),
        'turbine_id' => $conn->real_escape_string($obj['turbine_id'] ?? ''),
        'wtg_no' => $conn->real_escape_string($obj['wtg_no'] ?? ''),
        'loc_no' => $conn->real_escape_string($obj['loc_no'] ?? ''),
        'model_id' => $conn->real_escape_string($obj['model_id'] ?? ''),
        'model_type' => $conn->real_escape_string($obj['model_type'] ?? ''),
        'htsc_no' => $conn->real_escape_string($obj['htsc_no'] ?? ''),
        'capacity' => floatval($obj['capacity'] ?? 0),
        'make' => $conn->real_escape_string($obj['make'] ?? ''),
        'csr_booked_by' => $conn->real_escape_string($obj['csr_booked_by'] ?? ''),
        'csr_booked_by_date' => $conn->real_escape_string($obj['csr_booked_by_date'] ?? ''),
        'csr_booked_by_time' => $conn->real_escape_string($obj['csr_booked_by_time'] ?? ''),
        'nature_of_work' => $conn->real_escape_string($obj['nature_of_work'] ?? ''),
        'system_down' => isset($obj['system_down']) ? (int)$obj['system_down'] : 0,
        'system_down_date' => $conn->real_escape_string($obj['system_down_date'] ?? ''),
        'system_down_time' => $conn->real_escape_string($obj['system_down_time'] ?? ''),
        'work_st_date' => $conn->real_escape_string($obj['work_st_date'] ?? ''),
        'work_st_time' => $conn->real_escape_string($obj['work_st_time'] ?? ''),
        'work_end_date' => $conn->real_escape_string($obj['work_end_date'] ?? ''),
        'work_end_time' => $conn->real_escape_string($obj['work_end_time'] ?? ''),

        'parts_data' => json_encode($obj['parts_data'] ?? [], JSON_UNESCAPED_SLASHES),
        'employee_name' => $conn->real_escape_string($obj['employee_name'] ?? ''),
        'incharge_operator_name' => $conn->real_escape_string($obj['incharge_operator_name'] ?? '')
    ];

    // Validate required fields (adjust as per your requirements)
    $required = ['csr_no', 'customer_id', 'turbine_id', 'wtg_no'];
    foreach ($required as $field) {
        if (empty($fields[$field])) {
            $output["head"]["code"] = 400;
            $output["head"]["msg"] = "Please provide all required fields.";
            echo json_encode($output, JSON_NUMERIC_CHECK);
            exit();
        }
    }

    // Check if csr_no already exists
    $stmt = $conn->prepare("SELECT `id` FROM `csr_entry` WHERE `csr_no` = ? AND `delete_at` = 0");
    $stmt->bind_param("s", $fields['csr_no']);
    $stmt->execute();
    $check = $stmt->get_result();
    if ($check->num_rows > 0) {
        $output["head"]["code"] = 400;
        $output["head"]["msg"] = "CSR number already exists.";
        echo json_encode($output, JSON_NUMERIC_CHECK);
        exit();
    }
    $stmt->close();

    // Handle image uploads
    $employee_sign = '';
    if (!empty($obj['employee_sign'])) {
        $imgResult = processImage($obj['employee_sign'], 'employee_sign');
        if (isset($imgResult['error'])) {
            $output["head"]["code"] = 400;
            $output["head"]["msg"] = $imgResult['error'];
            echo json_encode($output, JSON_NUMERIC_CHECK);
            exit();
        }
        $employee_sign = str_replace($base_url . '/', '../', $imgResult['path']);
    }

    $incharge_operator_sign = '';
    if (!empty($obj['incharge_operator_sign'])) {
        $imgResult = processImage($obj['incharge_operator_sign'], 'incharge_operator_sign');
        if (isset($imgResult['error'])) {
            $output["head"]["code"] = 400;
            $output["head"]["msg"] = $imgResult['error'];
            echo json_encode($output, JSON_NUMERIC_CHECK);
            exit();
        }
        $incharge_operator_sign = str_replace($base_url . '/', '../', $imgResult['path']);
    }

    $stmt = $conn->prepare("INSERT INTO `csr_entry` (
        `csr_no`, `csr_entry_date`, `customer_id`, `customer_name`, `contract_id`, `contract_type`,
        `error_id`, `error_details`, `turbine_id`, `wtg_no`, `loc_no`, `model_id`, `model_type`,
        `htsc_no`, `capacity`, `make`, `csr_booked_by`, `csr_booked_by_date`, `csr_booked_by_time`,
        `nature_of_work`, `system_down`, `system_down_date`, `system_down_time`, `work_st_date`,
        `work_st_time`, `work_end_date`, `work_end_time`, `parts_data`, `employee_name`,
        `employee_sign`, `incharge_operator_name`, `incharge_operator_sign`, `create_at`, `delete_at`
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)");
    $stmt->bind_param(
        "ssssssssssssssssssssissssssssssss",
        $fields['csr_no'],
        $fields['csr_entry_date'],
        $fields['customer_id'],
        $fields['customer_name'],
        $fields['contract_id'],
        $fields['contract_type'],
        $fields['error_id'],
        $fields['error_details'],
        $fields['turbine_id'],
        $fields['wtg_no'],
        $fields['loc_no'],
        $fields['model_id'],
        $fields['model_type'],
        $fields['htsc_no'],
        $fields['capacity'],
        $fields['make'],
        $fields['csr_booked_by'],
        $fields['csr_booked_by_date'],
        $fields['csr_booked_by_time'],
        $fields['nature_of_work'],
        $fields['system_down'],
        $fields['system_down_date'],
        $fields['system_down_time'],
        $fields['work_st_date'],
        $fields['work_st_time'],
        $fields['work_end_date'],
        $fields['work_end_time'],
        $fields['parts_data'],
        $fields['employee_name'],
        $employee_sign,
        $fields['incharge_operator_name'],
        $incharge_operator_sign,
        $timestamp
    );

    if ($stmt->execute()) {
        $id = $conn->insert_id;
        $uniqueCsrID = uniqueID('csr_entry', $id);
        $stmt = $conn->prepare("UPDATE `csr_entry` SET `csr_entry_id` = ?, `csr_no_id` = ? WHERE `id` = ?");
        $stmt->bind_param("ssi", $uniqueCsrID, $uniqueCsrID, $id);
        $stmt->execute();
        $stmt->close();

        $output["head"]["code"] = 200;
        $output["head"]["msg"] = "CSR entry added successfully";
        $output["body"] = array_merge(
            ['id' => $id, 'csr_entry_id' => $uniqueCsrID, 'csr_no_id' => $uniqueCsrID, 'create_at' => $timestamp, 'delete_at' => 0],
            $fields,
            [
                'employee_sign' => $employee_sign ? $base_url . '/' . str_replace('../', '', $employee_sign) : '',
                'incharge_operator_sign' => $incharge_operator_sign ? $base_url . '/' . str_replace('../', '', $incharge_operator_sign) : ''
            ]
        );
    } else {
        error_log("CSR creation failed: " . $stmt->error);
        $output["head"]["code"] = 400;
        $output["head"]["msg"] = "Failed to add CSR entry.";
        echo json_encode($output, JSON_NUMERIC_CHECK);
        exit();
    }
}
// <<<<<<<<<<===================== Update CSR Entry =====================>>>>>>>>>>
elseif (isset($obj['edit_csr_entry_id'])) {
    $edit_id = $conn->real_escape_string($obj['edit_csr_entry_id']);
    $fields = [
        'csr_no' => $conn->real_escape_string($obj['csr_no'] ?? ''),
        'csr_entry_date' => $conn->real_escape_string($obj['csr_entry_date'] ?? ''),
        'customer_id' => $conn->real_escape_string($obj['customer_id'] ?? ''),
        'customer_name' => $conn->real_escape_string($obj['customer_name'] ?? ''),
        'contract_id' => $conn->real_escape_string($obj['contract_id'] ?? ''),
        'contract_type' => $conn->real_escape_string($obj['contract_type'] ?? ''),
        'error_id' => $conn->real_escape_string($obj['error_id'] ?? ''),
        'error_details' => $conn->real_escape_string($obj['error_details'] ?? ''),
        'turbine_id' => $conn->real_escape_string($obj['turbine_id'] ?? ''),
        'wtg_no' => $conn->real_escape_string($obj['wtg_no'] ?? ''),
        'loc_no' => $conn->real_escape_string($obj['loc_no'] ?? ''),
        'model_id' => $conn->real_escape_string($obj['model_id'] ?? ''),
        'model_type' => $conn->real_escape_string($obj['model_type'] ?? ''),
        'htsc_no' => $conn->real_escape_string($obj['htsc_no'] ?? ''),
        'capacity' => $conn->real_escape_string($obj['capacity'] ?? ''),
        'make' => $conn->real_escape_string($obj['make'] ?? ''),
        'csr_booked_by' => $conn->real_escape_string($obj['csr_booked_by'] ?? ''),
        'csr_booked_by_date' => $conn->real_escape_string($obj['csr_booked_by_date'] ?? ''),
        'csr_booked_by_time' => $conn->real_escape_string($obj['csr_booked_by_time'] ?? ''),
        'nature_of_work' => $conn->real_escape_string($obj['nature_of_work'] ?? ''),
        'system_down' => isset($obj['system_down']) ? (int)$obj['system_down'] : 0,
        'system_down_date' => $conn->real_escape_string($obj['system_down_date'] ?? ''),
        'system_down_time' => $conn->real_escape_string($obj['system_down_time'] ?? ''),
        'work_st_date' => $conn->real_escape_string($obj['work_st_date'] ?? ''),
        'work_st_time' => $conn->real_escape_string($obj['work_st_time'] ?? ''),
        'work_end_date' => $conn->real_escape_string($obj['work_end_date'] ?? ''),
        'work_end_time' => $conn->real_escape_string($obj['work_end_time'] ?? ''),

        'parts_data' => json_encode($obj['parts_data'] ?? [], JSON_UNESCAPED_SLASHES),
        'employee_name' => $conn->real_escape_string($obj['employee_name'] ?? ''),
        'incharge_operator_name' => $conn->real_escape_string($obj['incharge_operator_name'] ?? '')
    ];

    // Validate required fields
    $required = ['csr_no', 'customer_id', 'turbine_id', 'wtg_no'];
    foreach ($required as $field) {
        if (empty($fields[$field])) {
            $output["head"]["code"] = 400;
            $output["head"]["msg"] = "Please provide all required fields.";
            echo json_encode($output, JSON_NUMERIC_CHECK);
            exit();
        }
    }

    // Check if csr_no exists in another record
    $stmt = $conn->prepare("SELECT `id` FROM `csr_entry` WHERE `csr_no` = ? AND `csr_entry_id` != ? AND `delete_at` = 0");
    $stmt->bind_param("ss", $fields['csr_no'], $edit_id);
    $stmt->execute();
    $check = $stmt->get_result();
    if ($check->num_rows > 0) {
        $output["head"]["code"] = 400;
        $output["head"]["msg"] = "CSR number already exists.";
        echo json_encode($output, JSON_NUMERIC_CHECK);
        exit();
    }
    $stmt->close();

    // Handle image uploads
    $employee_sign = '';
    if (!empty($obj['employee_sign'])) {
        $imgResult = processImage($obj['employee_sign'], 'employee_sign');
        if (isset($imgResult['error'])) {
            $output["head"]["code"] = 400;
            $output["head"]["msg"] = $imgResult['error'];
            echo json_encode($output, JSON_NUMERIC_CHECK);
            exit();
        }
        $employee_sign = str_replace($base_url . '/', '../', $imgResult['path']);
    }

    $incharge_operator_sign = '';
    if (!empty($obj['incharge_operator_sign'])) {
        $imgResult = processImage($obj['incharge_operator_sign'], 'incharge_operator_sign');
        if (isset($imgResult['error'])) {
            $output["head"]["code"] = 400;
            $output["head"]["msg"] = $imgResult['error'];
            echo json_encode($output, JSON_NUMERIC_CHECK);
            exit();
        }
        $incharge_operator_sign = str_replace($base_url . '/', '../', $imgResult['path']);
    }

    $query = "UPDATE `csr_entry` SET 
        `csr_no`=?, `csr_entry_date`=?, `customer_id`=?, `customer_name`=?, `contract_id`=?, `contract_type`=?, 
        `error_id`=?, `error_details`=?, `turbine_id`=?, `wtg_no`=?, `loc_no`=?, `model_id`=?, `model_type`=?, 
        `htsc_no`=?, `capacity`=?, `make`=?, `csr_booked_by`=?, `csr_booked_by_date`=?, `csr_booked_by_time`=?, 
        `nature_of_work`=?, `system_down`=?, `system_down_date`=?, `system_down_time`=?, `work_st_date`=?, 
        `work_st_time`=?, `work_end_date`=?, `work_end_time`=?,`parts_data`=?, `employee_name`=?, 
        `employee_sign`=IF(? != '', ?, `employee_sign`), `incharge_operator_name`=?, 
        `incharge_operator_sign`=IF(? != '', ?, `incharge_operator_sign`)
        WHERE `csr_entry_id`=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param(
        "ssssssssssssssssssssissssssssssssss",
        $fields['csr_no'],
        $fields['csr_entry_date'],
        $fields['customer_id'],
        $fields['customer_name'],
        $fields['contract_id'],
        $fields['contract_type'],
        $fields['error_id'],
        $fields['error_details'],
        $fields['turbine_id'],
        $fields['wtg_no'],
        $fields['loc_no'],
        $fields['model_id'],
        $fields['model_type'],
        $fields['htsc_no'],
        $fields['capacity'],
        $fields['make'],
        $fields['csr_booked_by'],
        $fields['csr_booked_by_date'],
        $fields['csr_booked_by_time'],
        $fields['nature_of_work'],
        $fields['system_down'],
        $fields['system_down_date'],
        $fields['system_down_time'],
        $fields['work_st_date'],
        $fields['work_st_time'],
        $fields['work_end_date'],
        $fields['work_end_time'],
        $fields['parts_data'],
        $fields['employee_name'],
        $employee_sign,
        $employee_sign,
        $fields['incharge_operator_name'],
        $incharge_operator_sign,
        $incharge_operator_sign,
        $edit_id
    );


    if ($stmt->execute()) {
        $output["head"]["code"] = 200;
        $output["head"]["msg"] = "CSR entry updated successfully";
        $output["body"] = array_merge(
            ['csr_entry_id' => $edit_id],
            $fields,
            [
                'employee_sign' => $employee_sign ? $base_url . '/' . str_replace('../', '', $employee_sign) : '',
                'incharge_operator_sign' => $incharge_operator_sign ? $base_url . '/' . str_replace('../', '', $incharge_operator_sign) : ''
            ]
        );
    } else {
        error_log("CSR update failed: " . $stmt->error);
        $output["head"]["code"] = 400;
        $output["head"]["msg"] = "Failed to update CSR entry.";
        echo json_encode($output, JSON_NUMERIC_CHECK);
        exit();
    }
    $stmt->close();
}
// <<<<<<<<<<===================== Delete CSR Entry =====================>>>>>>>>>>
elseif (isset($obj['delete_csr_entry_id'])) {
    $delete_id = $conn->real_escape_string($obj['delete_csr_entry_id']);
    if (empty($delete_id)) {
        $output["head"]["code"] = 400;
        $output["head"]["msg"] = "Please provide the CSR entry ID to delete.";
        echo json_encode($output, JSON_NUMERIC_CHECK);
        exit();
    }

    $stmt = $conn->prepare("UPDATE `csr_entry` SET `delete_at` = 1 WHERE `csr_entry_id` = ?");
    $stmt->bind_param("s", $delete_id);
    if ($stmt->execute()) {
        $output["head"]["code"] = 200;
        $output["head"]["msg"] = "CSR entry deleted successfully";
    } else {
        error_log("CSR deletion failed: " . $stmt->error);
        $output["head"]["code"] = 400;
        $output["head"]["msg"] = "Failed to delete CSR entry.";
    }
    $stmt->close();
}
// <<<<<<<<<<===================== List get_turbine_data =====================>>>>>>>>>>
elseif (isset($obj['action']) && $obj['action'] === 'get_turbine_data') {
    try {
        $query = "
            SELECT 
                t.turbine_id,
                t.wtg_no,
                t.customer_id,
                t.loc_no,
                t.htsc_no,
                t.model_id,
                t.contracttype_id,
                t.capacity,
                t.ctpt_make,
                c.customer_name,
                m.model_type,
                ct.contract_code
            FROM 
                turbine t
            LEFT JOIN 
                customer c ON t.customer_id = c.customer_unique_id
            LEFT JOIN 
                model m ON t.model_id = m.model_id
            LEFT JOIN 
                contract_type ct ON t.contracttype_id = ct.contract_id
            WHERE 
                t.delete_at = 0
            GROUP BY 
                t.wtg_no
            ORDER BY 
                t.wtg_no
        ";

        $result = $conn->query($query);

        if ($result === false) {
            throw new Exception("Query failed: " . $conn->error);
        }

        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        $output["head"]["code"] = 200;
        $output["head"]["msg"] = "Data retrieved successfully";
        $output["body"] = $data;
    } catch (Exception $e) {
        error_log("Error: " . $e->getMessage());
        $output["head"]["code"] = 400;
        $output["head"]["msg"] = "Failed to retrieve data. Please try again.";
    }
} else {
    $output["head"]["code"] = 400;
    $output["head"]["msg"] = "Parameter mismatch or invalid action";
}

echo json_encode($output, JSON_NUMERIC_CHECK);
$conn->close();
