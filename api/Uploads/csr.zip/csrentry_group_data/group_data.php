<?php
include("../config/db_config.php");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit();
}

$output = array();
date_default_timezone_set('Asia/Calcutta');
$timestamp = date('Y-m-d H:i:s');

try {

    $query = "
        SELECT 
            t.turbine_id,
            t.wtg_no,
            t.customer_id,
            t.loc_no,
            t.htsc_no,
            t.model_id,
            t.contracttype_id,
            t.capacity,
            t.ctpt_make,
            c.customer_name,
            m.model_type,
            ct.contract_code
        FROM 
            turbine t
        LEFT JOIN 
            customer c ON t.customer_id = c.customer_unique_id
        LEFT JOIN 
            model m ON t.model_id = m.model_id
        LEFT JOIN 
            contract_type ct ON t.contracttype_id = ct.contract_id
        WHERE 
            t.delete_at = 0
        GROUP BY 
            t.wtg_no
        ORDER BY 
            t.wtg_no
    ";

    $result = $conn->query($query);

    if ($result === false) {
        throw new Exception("Query failed: " . $conn->error);
    }

    $data = array();
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    $output["head"]["code"] = 200;
    $output["head"]["msg"] = "Data retrieved successfully";
    $output["body"] = $data;
} catch (Exception $e) {
    error_log("Error: " . $e->getMessage());
    $output["head"]["code"] = 400;
    $output["head"]["msg"] = "Failed to retrieve data. Please try again.";
}

echo json_encode($output, JSON_NUMERIC_CHECK);
$conn->close();
